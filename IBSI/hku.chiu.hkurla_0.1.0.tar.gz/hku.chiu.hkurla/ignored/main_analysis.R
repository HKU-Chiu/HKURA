source("./R/preparedata.R")

gplotsave = function(x) ggsave(filename = paste0(x,".png"), plot = get(x), units = "in", width = 14, height = 10)
gplotsaveL = function(x) ggsave(filename = paste0(x,".png"), plot = get(x), units = "in", width = 10, height = 14)
library(scales)

##--- Histograms

p1A = ibsicohorts %>% # 1. all (normalized) feature values. Color-compose hist bars by library factor.
  ggplot(aes(x = norm.value)) +
  geom_histogram(aes(y = stat(count / sum(count)), fill = library), color = "black",#linetype = "solid",
                 bins = 100) +
  labs(subtitle = "Per library composition",
       y = "Relative frequency",
       x = "Normalized Feature Value",
       title = "Histogram of feature values",
       caption = "Source: HKU Diagnostic Radiology")
#gplotsave("p1A")

p1B = ibsicohorts %>% #2. clipped range all feature values. Color-compose hist bars by library factor. Shows distribution drop at value > 1
  ggplot(aes(x = value)) +
  geom_histogram(aes(y = stat(count / sum(count)), fill = library), color = "black",
                 bins = 100) +
  xlim(c(0, 2)) +
  ylim(c(0, .15)) +
  labs(subtitle = "Per library composition",
       y = "Relative frequency",
       x = "Feature Value",
       title = "Histogram of feature values",
       caption = "Source: HKU Diagnostic Radiology")
#gplotsave("p1B")

p1C = ibsicohorts %>%
  group_by(`ibsi code`, library) %>%
  summarize(n.avg = n()/108) %>%
  ggplot(aes(x = `ibsi code`, y = n.avg)) + geom_bar(aes(fill = library), color = "gray", stat = "identity") +
  labs(subtitle = "Per library composition",
       y = "Average counts per patient",
       x = "Feature IBSI Code",
       title = "Histogram of implementation frequency",
       caption = "Source: HKU Diagnostic Radiology")+
  scale_y_continuous(breaks=pretty_breaks(n=10))


p1D = ibsicohorts %>% # facet each feature.
  ggplot(aes(x = norm.value)) +

  geom_histogram(aes(y = stat(density / 400), fill = library),
                 bins = 100) +
  scale_y_continuous(labels = scales::percent) +
  facet_wrap(~ `ibsi code`, ncol = 6,  scales="free_y") +
   labs(subtitle = "With color-coded library composition",
        y = "Relative frequency",
        x = "Normalized Feature Value",
        title = "Histograms per Feature",
        caption = "Source: HKU Diagnostic Radiology")
gplotsave("p1D")

p2B = ibsicohorts %>%
  ggplot(aes(x = norm.value, color = library, fill = library)) +
  geom_density(alpha = .15) +
  labs(subtitle = "Equal area decomposition of the total histogram",
       y = "Density",
       x = "Normalized Feature Value",
       title = "Density plots per Library",
       caption = "Source: HKU Diagnostic Radiology")
gplotsave("p2B")

p2C = ibsicohorts %>%
  ggplot(aes(x = norm.value, y = `ibsi code`)) +
  ggridges::geom_density_ridges()
labs(subtitle = "Equal area decomposition of the total histogram",
     y = "Feature",
     x = "Normalized Feature Value",
     title = "Histograms per Feature",
     caption = "Source: HKU Diagnostic Radiology")
gplotsave("p2C")

# 3. scatterplots
#Basic values per feature, similar to histogram. pretty
p3A = ibsicohorts %>%
  filter(!value > 1e8) %>%
  ggplot(aes(y = norm.value, x = `ibsi code`, color = library)) +
  geom_point(aes(color = library),
              size = 1.5, alpha = .5,
             position = position_jitter(width = .25, height = 0)) +
  labs(subtitle = "Normalized Feature Values by Feature",
     y = "Normalized value",
     x = "Feature",
     title = "Scatterplot",
     caption = "Source: HKU Diagnostic Radiology")
gplotsave("p3A")

#Feature values per patient, faceted by feature
# Alternative: vertically stacked, factor label on the right (e.g. GGally::ggts)
p3B = ibsicohorts %>%
  filter(!value > 1e8) %>%
  ggplot(aes(y = norm.value, x = PatientID)) +
  geom_point(aes(color = library),
             size = 1.5, alpha = .5) +
  scale_x_discrete(labels = NULL)+
  facet_wrap(~ `ibsi code`, ncol = 6) +
  labs(subtitle = "Normalized Feature Values by Patient",
       y = "Normalized Features values",
       x = "Patient",
       title = "Scatterplot",
       caption = "Source: HKU Diagnostic Radiology")
plot(p3B)

#library pairwise features: faceted 6 library combinations (cgita vs cerr, etc)

p3C = pairdata %>%
  filter(!value.x > 1e6) %>%
  ggplot(aes(x = norm.value.x, y = norm.value.y)) +
  geom_point() +
  geom_smooth(method = "lm") +
  facet_wrap(library.x ~ library.y, ncol = 2)+
  labs(subtitle = "Pairwise library comparison of features",
     y = "Normalized Feature values",
     x = "Normalized Feature values",
     title = "Scatterplot",
     caption = "Source: HKU Diagnostic Radiology")
plot(p3C)

# alternative pairwise: just averages with text labels
makePairs = function(df, fac, key){
  lvls = as.vector(t(unique(select(df, !!ensym(fac)))))
  perms = combn(lvls, 2, simplify = FALSE)
  map_dfr(perms, ~ {
    a = filter(df, !!ensym(fac) == .x[1])
    b = filter(df, !!ensym(fac) == .x[2])
    return(inner_join(a, b, by = key)) #bind_cols if you're confident
  })
}

temp_summary = ibsicohorts %>%
  filter(!value >1e4) %>%
  group_by(library, `ibsi code`) %>%
  summarize(avg = mean(norm.value)) %>%
  makePairs(library, "ibsi code")


p3D = temp_summary %>%
  ggplot(aes(x = avg.x, y = avg.y)) +
  geom_point(shape = 2, size = 2.4, stroke = 1.25, color = "yellow") +
  ggrepel::geom_text_repel(aes(label = `ibsi code`, color =`ibsi code`, fontface = "bold"))+
  geom_smooth(method = "lm") +
  labs(title = "Pairwise Scatterplots of Feature Averages", colour = "IBSI code", x = "Average (normalized) value", y = "Average (normalized) value") +
  facet_wrap(library.x ~ library.y, ncol = 2)+
  theme_dark()
plot(p3D)


# 4. Lineplots
# avg featureset vs. patient ID.
p4A = ibsicohorts %>%
  filter(!value > 1e8) %>%
  distinct(library, `ibsi code`, PatientID, .keep_all = TRUE) %>%
  ggplot(aes(y = norm.value, x = PatientID, group = `ibsi code`)) +
  geom_smooth(aes(color = `ibsi code`), alpha = .25) +
  scale_x_discrete(labels = NULL)+
  labs(subtitle = "Average Normalized Feature Values in cohort",
       y = "Normalized Features values",
       x = "Patient",
       title = "Line plot",
       fill = "Feature",
       caption = "Source: HKU Diagnostic Radiology")
plot(p4A)
gplotsave("p4A")
#line plot/slope chart of features vs library, or feature avg vs library
#TBA

# PCP of libraries
p4B = ibsicohorts %>%
  distinct(library, `ibsi code`, PatientID, .keep_all = TRUE) %>% #smarter: count ibsicode freq and choose LCD
  filter(!value > 1e8) %>%
  select(-feature, -norm.value) %>%
  spread(library, value) %>%
  GGally::ggparcoord(alpha = .25, scale = "center", column = 3:6) +
  ylim(c(-.1,.25))+
  scale_colour_manual(values="steelblue", guide=FALSE)+
  labs(subtitle = "Feature Relations Between Libraries",
       y = "Normalized Feature Value",
       x = "Library",
       title = "Parallel Coordinate Plot",
       caption = "Source: HKU Diagnostic Radiology")
p4B$mapping$colour = "steelblue"
p4B +  scale_colour_manual(values="steelblue", guide=FALSE)
plot(p4B)
#http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/
# PCP of unique features, colored by library
p4C = ibsicohorts %>%
  distinct(library, `ibsi code`, PatientID, .keep_all = TRUE) %>% #smarter: count ibsicode freq and choose LCD
  select(-feature, -norm.value) %>%
  spread(`ibsi code`, value) %>%
  GGally::ggparcoord(alpha = .15, scale = "center", column = 3:26, groupColumn = "library", boxplot = TRUE) +
  labs(subtitle = "Linkage across feature dimensions",
     y = "Normalized value",
     x = "Feature",
     title = "Parallel Coordinate Plot",
     caption = "Source: HKU Diagnostic Radiology")
plot(p4C)


# 5.  vertical boxplots
#as shown by tutorial. y-axis = 4 x features 1...N.  x-axis = normalized value or log(norm_value). Consider adding dots.

# 6. heatmaps
# y = feature. x = 4 x patient. z(color) = feature value
# Divide into mosaic heat maps per feature
# Missing values

# 7. single feature mean-deviation histogram

# 8 Text summary of each feature after grouping by library. Put results into a new dataframe.



#--- Part 2: Intraset correlation
# correlogram
#ggcorrplot::ggcorrplot()
# scatter between 2 highly correlated features, size by volume, shape by library
#
# For each library, determine the set of low-correlation features -> table
# See if the combined megaset has a larger set of low-correlates -> good for modeling

