# we're interested in ibsi features common to all libraries
common = ibsidata[["merged"]] #use the pre-made ibsi overview data
common = na.exclude(common) #removes features with 0,1,2 or 3 matches

##--- For each library, subset the cohortdata with the common featureset.
#Requires cohortmap. For the reasoning behind this see ?cohortmap

#Get the feature IDs of the common featureset for each library
featureVars = c("Feature CGITA ID", "CERR Feature ID", "IBEX Feature ID", "MVAL feature ID")
assertthat::assert_that(all(featureVars %in% colnames(common))) #check for typos
IDvalues = map(common[, featureVars], unique)

#intermezzo: ensuring names are consistent facilitates lookups
cohortmap = map2(cohortmap, as.list(featureVars), function(x, y){
  colnames(x)[2] = y  #x =  x %>% rename_at(.vars = secondcol, ~y)
  return(x)
})

#now convert each set of n feature IDs to set of N strings(where N >= n)
selectors = map2(cohortmap, IDvalues, function(dict, IDs){
  IDname = colnames(dict)[2] #we've ensured IDname is consistent in both dataframes
  dict %>%
    filter(get(IDname) %in% IDs) %>%
    left_join(unique(common[, c(IDname, "ibsi code")]), by = IDname) %>%
    select(-IDname) #no longer need this variable
})


# mappedSelectors = mapply(function(dict, IDcodes){
#   dict[dict[, 2] %in% IDcodes, 1] #dictionary lookup (2=ID, 1=string), dropped to vector
# }, cohortmap, selectors) #preserves 1st arg names?

#ibsicohort = mapply(function(x){
#subset
#rename with ibsi code (ibsi names aren't unique)
#}, mappedSelectors, cohortdata) #list of subsetted dataframes


#
# [1] "ibsi code"              "ibsi name"              "Feature CGITA ID"
# [4] "Feature CGITA name"     "Feature CGITA category" "CERR Feature ID"
# [7] "CERR Feature name"      "CERR Category"          "IBEX Feature ID"
# [10] "IBEX feature name"      "IBEX category"          "MVAL feature ID"
# [13] "MVAL feature name"      "MVAL category"

# map(gather, key = "feature", value = "value", -PatientID) %>%
# map2(selectors, left_join, by = c("feature" = "MATLAB name")) %>%
