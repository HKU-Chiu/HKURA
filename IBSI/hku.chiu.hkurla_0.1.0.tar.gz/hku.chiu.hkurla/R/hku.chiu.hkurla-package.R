#' @keywords internal
#' @docType package
#' @name hkurla
#' @section Notes:
#' This package contains the radiomics data used in the following publication:
#'
#' This package is part of the HKURLA project hosted at: \url{http://rstudio.com}.
#' If you are using HKURLA in your analysis, please cite the above paper.
#' 
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL