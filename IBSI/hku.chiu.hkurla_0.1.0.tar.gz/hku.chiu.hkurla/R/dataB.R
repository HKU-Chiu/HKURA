#' Cleaned Radiomics Dataset for Esophagus PET lesions
#'
#' 4 Library featuresets, the IBSI featureset, and the left-join of the 4 libraries with the IBSI featureset (merged on ibsi code).
#' 
#'
#' @format A list of 6 data frames, the four libraries have the variables:
#' \describe{
#'   \item{Library ID}{An integer corresponding to name}
#'   \item{Library feature name}{Original name of feature}
#'   \item{Library feature category}{Original category of feature}
#'   \item{ibsi name}{if applicable, denotes the possible IBSI-equivalent feature name}
#'   \item{ibsi code}{code corresponding to ibsi name, according to standard documentation}
#'   ...
#' }
#' @source K.w.h. Chiu, dept. of diagnostic radiology HKU
"ibsidata"
