#' cohortmap: Helper dataset to link cohortdata and ibsidata.
#'
#' Helper dataset to link cohortdata and ibsidata. Maps 4 Original featuresets from: CGITA, CERR, IBEX and MVAL. 
#' Mapping step is necessary because MATLAB (cohortdata) can't generate variables with the strings used in the ibsidata because:
#' \describe{
#'   \item{Invalid MATLAB strings}{MATLAB doesn't support tables with variables that contain hyphens or dots, etc}
#'   \item{Non-scalar features}{Require name-suffixes, e.g. "percentile" is a single ibsi feature but isn't a single output variable}
#'   \item{Non-unique variable names}{Require name-suffixes or prefixes, e.g. energy for various categories}
#'}
#' 
#' 
#'
#' @format A list of 2-column data frames. First column is the variable name in the cohortdata, i.e. the MATLAB-generated string denoting the feature name, the second column is the library feature ID. 
#' @source K.w.h. Chiu, dept. of diagnostic radiology HKU
"cohortmap"
