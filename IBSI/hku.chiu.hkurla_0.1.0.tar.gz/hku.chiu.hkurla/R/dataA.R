#' Cleaned Radiomics Dataset for Esophagus PET lesions
#'
#' 4 Original featuresets from: CGITA, CERR, IBEX and MVAL. Originally run on 111 patients, but has removed patients with failed contours.
#' Some values may be NA or zero depending on how the library deals with input it can't handle.
#' 
#' 
#'
#' @format A list of data frames, each has a specific set of features. Feature names are MATLAB strings, which can be mapped to library ID using cohortmap.
#' @source K.w.h. Chiu, dept. of diagnostic radiology HKU
"cohortdata"
